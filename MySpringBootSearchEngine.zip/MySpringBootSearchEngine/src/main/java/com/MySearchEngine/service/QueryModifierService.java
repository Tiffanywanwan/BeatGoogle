package com.MySearchEngine.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class QueryModifierService {
    
    // 簡易同義詞表 (key=主要詞, value=其同義或近似詞)
    private static final Map<String, String[]> SYNONYM_MAP = new HashMap<>();
    static {
        // 「狗」擴充 -> 「狗狗, dog」
        SYNONYM_MAP.put("狗", new String[]{"狗狗", "dog"});
        SYNONYM_MAP.put("貓", new String[]{"貓咪", "cat"});
        SYNONYM_MAP.put("圖案", new String[]{"印花", "pattern"});
        // 你可以依需求再加入更多
    }

    /**
     * 根據使用者輸入的字串，做簡易斷詞+同義詞擴充。
     */
    public String modifyQuery(String originalQuery) {
        String query = originalQuery.trim();
        // 為了示範，先用最簡單的空白切分 (實務可用 jieba, ckip, etc.)
        String[] tokens = query.split("\\s+");

        StringBuilder sb = new StringBuilder();
        for (String token : tokens) {
            sb.append(token).append(" ");
            // 如果 token 在同義詞表中，擴充
            if (SYNONYM_MAP.containsKey(token)) {
                for (String syn : SYNONYM_MAP.get(token)) {
                    sb.append(syn).append(" ");
                }
            }
        }

        // 最後再補上一些固定關鍵詞，例如「服飾, 購買」以確保能抓到衣服、商品相關
        sb.append("服飾 購買");

        return sb.toString().trim();
    }
}
