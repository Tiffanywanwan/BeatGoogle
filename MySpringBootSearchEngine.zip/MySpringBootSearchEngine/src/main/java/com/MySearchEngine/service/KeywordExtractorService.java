package com.MySearchEngine.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.MySearchEngine.model.WebPageNode;

@Service
public class KeywordExtractorService {

    // 舉例：如果網頁的標題出現「狗圖案」，算一次 +2 分；若描述裡出現，再 +1 分。
    // 這裡定義 "titleWeight" 與 "descWeight" 來區分。
    private static final Map<String, Double> KEYWORD_TITLE_WEIGHT = new HashMap<>();
    private static final Map<String, Double> KEYWORD_DESC_WEIGHT = new HashMap<>();
    
    static {
        // Title 關鍵字 (出現在標題時給比較高權重)
        KEYWORD_TITLE_WEIGHT.put("服飾", 3.0);
        KEYWORD_TITLE_WEIGHT.put("服裝", 3.0);
        KEYWORD_TITLE_WEIGHT.put("衣服", 3.0);
        KEYWORD_TITLE_WEIGHT.put("產品", 1.5);
        KEYWORD_TITLE_WEIGHT.put("商品", 1.5);
        KEYWORD_TITLE_WEIGHT.put("圖案", 2.5);
        KEYWORD_TITLE_WEIGHT.put("印花", 2.5);
        KEYWORD_TITLE_WEIGHT.put("tshirt", 1.5);
        // 如果有「寵物服飾」(判定這是不想要的)
        KEYWORD_TITLE_WEIGHT.put("寵物服飾", -3000.0);

        // Desc 關鍵字 (出現在描述時給比較低權重，但仍有影響)
        KEYWORD_DESC_WEIGHT.put("服飾", 1.0);
        KEYWORD_DESC_WEIGHT.put("衣服", 1.0);
        KEYWORD_DESC_WEIGHT.put("服裝", 1.0);
        KEYWORD_DESC_WEIGHT.put("評價", 1.0);
        KEYWORD_DESC_WEIGHT.put("評分", 1.0);
        KEYWORD_DESC_WEIGHT.put("購買", 1.0);
        KEYWORD_DESC_WEIGHT.put("產品", 1.0);
        KEYWORD_DESC_WEIGHT.put("出貨", 1.0);
        KEYWORD_DESC_WEIGHT.put("商品", 1.0);
        KEYWORD_DESC_WEIGHT.put("優惠", 1.0);
        KEYWORD_DESC_WEIGHT.put("購物車", 1.0);
        KEYWORD_DESC_WEIGHT.put("取貨", 1.0);
        KEYWORD_DESC_WEIGHT.put("圖案", 1.5);
        KEYWORD_DESC_WEIGHT.put("印花", 1.5);
        KEYWORD_DESC_WEIGHT.put("tshirt", 1.0);

        KEYWORD_DESC_WEIGHT.put("寵物服飾", -2000.0);
    }

    public double calculateScore(WebPageNode node) {
    String title = node.getName() != null ? node.getName().toLowerCase() : "";
    String desc  = node.getDescription() != null ? node.getDescription().toLowerCase() : "";

    double score = 0.0;
    // 計算標題
    for (Map.Entry<String, Double> entry : KEYWORD_TITLE_WEIGHT.entrySet()) {
        String keyword = entry.getKey();
        double weight = entry.getValue();
        int cnt = countOccurrences(title, keyword);
        score += cnt * weight;
    }

    // 計算描述
    for (Map.Entry<String, Double> entry : KEYWORD_DESC_WEIGHT.entrySet()) {
        String keyword = entry.getKey();
        double weight = entry.getValue();
        int cnt = countOccurrences(desc, keyword);
        score += cnt * weight;
    }

    // Return only non-negative scores
    return Math.max(score, 0);
}


    /**
     * 計算文字中出現 pattern 的次數
     */
    private int countOccurrences(String text, String pattern) {
        if (pattern == null || pattern.isEmpty()) return 0;
        int count = 0;
        int index = 0;
        while ((index = text.indexOf(pattern, index)) != -1) {
            count++;
            index += pattern.length();
        }
        return count;
    }
}
