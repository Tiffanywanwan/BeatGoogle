package com.MySearchEngine.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.MySearchEngine.model.WebPageNode;

@Service
public class GoogleQueryService {
    private static final String[] EXTRA_KEYWORDS = {"衣服", "優惠", "商品"};

    public List<WebPageNode> search(String query) {
        // 自動組合 + 假資料
        StringBuilder combined = new StringBuilder(query.trim());
        for (String kw : EXTRA_KEYWORDS) {
            combined.append(" ").append(kw);
        }

        List<WebPageNode> results = new ArrayList<>();
        results.add(new WebPageNode("【" + query + "】服飾購買頁",
            "https://example.com/" + query + "-clothes", 
            0.0,
            "https://example.com/images/" + query + "_clothes.jpg",
            "這裡有超可愛的 " + query + " 圖案印花服飾，快來選購！"));
        results.add(new WebPageNode(query + "潮流服裝介紹",
            "https://blog.example.com/" + query + "-fashion", 
            0.0,
            "https://example.com/images/" + query + "_fashion.jpg",
            "流行趨勢、印花設計與服飾推薦，在這裡找到你的 " + query + " 設計靈感。"));
        results.add(new WebPageNode(query + "印花T恤",
            "https://shop.example.com/" + query + "-tshirt", 
            0.0,
            "https://example.com/images/" + query + "_tshirt.jpg",
            "多款 " + query + " 印花T恤、圖案上衣，夏季必備。"));
        return results;
    }
}
