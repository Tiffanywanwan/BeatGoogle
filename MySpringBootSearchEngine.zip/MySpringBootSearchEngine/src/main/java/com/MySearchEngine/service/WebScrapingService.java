package com.MySearchEngine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import com.MySearchEngine.model.WebPageNode;

@Service
public class WebScrapingService {

    public List<WebPageNode> scrapeWeb(String query) {
        List<WebPageNode> results = new ArrayList<>();
        try {
            String url = "https://www.google.com/search?q=" + query + "衣服";

            Connection connection = Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                         + "AppleWebKit/537.36 (KHTML, like Gecko) "
                         + "Chrome/91.0.4472.124 Safari/537.36");

            Document doc = connection.get();

            // Google SERP 可能會變動，下面的選擇器僅供參考
            Elements searchResults = doc.select("div.g");
            for (Element result : searchResults) {
                Element link = result.selectFirst("a");
                Element title = result.selectFirst("h3");
                // 可能有描述的元素
                Element descElement = result.selectFirst("div.VwiC3b");

                if (link != null && title != null) {
                    String resultUrl = link.attr("href");
                    String resultTitle = title.text();
                    
                    // 過濾需要登入的網站
                    if (resultUrl.contains("shopee.tw")) {
                        continue; // 跳過
                    }

                    // 若有描述，抓一下文字
                    String desc = descElement != null ? descElement.text() : "";

                    // 此外，也可進一步到目標頁面再抓取 <meta name="description">
                    // 但這會大幅增加爬取時間與流量，這裡僅示範給你參考:
                    String metaDescription = fetchMetaDescription(resultUrl);

                    // 組合描述
                    String finalDescription = desc;
                    if (metaDescription != null && !metaDescription.isEmpty()) {
                        finalDescription += " | " + metaDescription;
                    }

                    WebPageNode node = new WebPageNode(resultTitle, resultUrl, 0.0, null, finalDescription);
                    results.add(node);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return results;
    }

    /**
     * 可嘗試進入該網址，抓取 meta description。
     * 注意：執行效率與連線風險，要評估是否真的需要做「二次爬取」。
     */
    private String fetchMetaDescription(String pageUrl) {
        try {
            // 避免抓到非 http(s) 的連結或怪連結
            if (!pageUrl.startsWith("http")) {
                return "";
            }
            Document pageDoc = Jsoup.connect(pageUrl)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                         + "AppleWebKit/537.36 (KHTML, like Gecko) "
                         + "Chrome/91.0.4472.124 Safari/537.36")
                .timeout(3000)
                .get();
            Element metaTag = pageDoc.selectFirst("meta[name=description]");
            if (metaTag != null) {
                return metaTag.attr("content");
            }
        } catch (IOException e) {
            // 若失敗就略過
        }
        return "";
    }
}
