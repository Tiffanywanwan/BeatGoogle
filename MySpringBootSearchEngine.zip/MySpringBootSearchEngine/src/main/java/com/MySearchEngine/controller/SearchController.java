package com.MySearchEngine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.MySearchEngine.model.WebPageNode;
import com.MySearchEngine.service.GoogleQueryService;
import com.MySearchEngine.service.KeywordExtractorService;
import com.MySearchEngine.service.QueryModifierService;
import com.MySearchEngine.service.ScoreCalculatorService;
import com.MySearchEngine.service.SortingService;
import com.MySearchEngine.service.WebScrapingService;

@Controller
public class SearchController {

    @Autowired
    private GoogleQueryService googleQueryService;

    @Autowired
    private QueryModifierService queryModifierService;

    @Autowired
    private WebScrapingService webScrapingService;

    @Autowired
    private KeywordExtractorService keywordExtractorService;

    @Autowired
    private ScoreCalculatorService scoreCalculatorService;

    @Autowired
    private SortingService sortingService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/search")
    public String search(String q, Model model) {
        // 0. 若無輸入 -> 回首頁
        if (q == null || q.trim().isEmpty()) {
            return "redirect:/";
        }

        // 1. 擴充同義詞
        String expandedQuery = queryModifierService.modifyQuery(q);

        // 2. 爬蟲
        List<WebPageNode> rawResults = webScrapingService.scrapeWeb(expandedQuery);

        // 3. 若爬取的結果為空 => 使用假資料
        if (rawResults.isEmpty()) {
            rawResults = googleQueryService.search(q);
        }

        // 4. 計算分數
        for (WebPageNode node : rawResults) {
            double score = keywordExtractorService.calculateScore(node);
            node.setScore(score);
        }

        // 5. 建樹狀結構 + 後序遍歷加總 + 排序
        if (!rawResults.isEmpty()) {
            WebPageNode root = rawResults.get(0);
            for (int i = 1; i < rawResults.size(); i++) {
                root.getChildren().add(rawResults.get(i));
            }
            scoreCalculatorService.postOrderCalculate(root);

            List<WebPageNode> sortedList = sortingService.sort(root);
            model.addAttribute("results", sortedList);
        } else {
            model.addAttribute("results", null);
        }

        model.addAttribute("keyword", q);
        return "result";
    }
}
