package com.MySearchEngine.model;

import java.util.ArrayList;
import java.util.List;

public class WebPageNode {
    private String name;
    private String url;
    private double score;
    private String imageUrl;
    private String description; // ← 新增：用來存放 meta 或內文
    private List<WebPageNode> children = new ArrayList<>();

    public WebPageNode(String name, String url, double score) {
        this(name, url, score, null, null);
    }

    public WebPageNode(String name, String url, double score, String imageUrl) {
        this(name, url, score, imageUrl, null);
    }

    public WebPageNode(String name, String url, double score, String imageUrl, String description) {
        this.name = name;
        this.url = url;
        this.score = score;
        this.imageUrl = imageUrl;
        this.description = description;
    }

    // Getter / Setter
    public String getName() { return name; }
    public String getUrl() { return url; }
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<WebPageNode> getChildren() { return children; }
}
