package com.MySearchEngine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootSearchEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootSearchEngineApplication.class, args);
	}

}
